import React from "react";
import "./footer.css";

const Footer = () => {
  return (
    <div className="footer">
      <div className="icones">
        <img src="./imagens/fb.png" alt="Logo do Faceboock" />
        <img src="./imagens/tw.png" alt="Logo do Twitter" />
        <img src="./imagens/ig.png" alt="Logo do Instagram" />
      </div>
      <div>
        <img src="./imagens/logo.png" alt="Logo da Organo" className="logoRp" />
      </div>
      <div className="desc">
        <p>Desenvolvido pelo Matheus.</p>
      </div>
    </div>
  );
};

export default Footer;
