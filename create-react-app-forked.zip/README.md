# Create React App

This is the files you get with the `npx create-react-app new my-awesome-app` bootstrap.

A base to start projects from.